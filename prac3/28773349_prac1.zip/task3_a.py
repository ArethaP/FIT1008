the_list = [] #create empty list
size = int(input('Size: '))
the_list.append(size)

init = 1
while init <= size: #init list and set all values to default 0 
	the_list.append(0)
	init += 1

app = 1
while app <= size: #add items to the list, replacing 0 with user defined value
	item = input('Item: ')
	the_list[app] = int(item)
	app += 1

#find min value in the list
count = 1
small = the_list[1]
while count <= size:
	if the_list[count] < small:
		small = the_list[count]
	count += 1

count = 1
large = the_list[1]
while count <= size:
	if the_list[count] > large:
		large = the_list[count]
	count += 1

print('range = ' + str(large - small))