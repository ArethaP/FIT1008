list_of_temps = []
size = int(input('Size: '))
list_of_temps.append(size)
init = 1
while init <= size: #init list and set all values to default 0 
	list_of_temps.append(0)
	init += 1

app = 1
while app <= size: #add items to the list, replacing 0 with user defined value
	item = input('Temperature: ')
	list_of_temps[app] = int(item)
	app += 1


target = int(input('What is the target temperature? '))
count = 1
success = 0
while count <= size:
	if list_of_temps[count] == target:
		success += 1
	count += 1

print(success)